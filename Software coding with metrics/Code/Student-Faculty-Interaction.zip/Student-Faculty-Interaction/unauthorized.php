<?php 

    echo '<h1>You do not have the authorization rights to view this!<br></h1>';
    echo '<h3><a href="return_to_moodle.php">Return to moodle</a><h3>';

?>